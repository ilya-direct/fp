<?php
if (!defined('_JEXEC'))
die('Direct Access to ' . basename(__FILE__) . ' is not allowed.');
/**
 * AddCustomerResult.class.php
 */

/**
 * Result data returned from {@link AvaCertServiceSoap#AddCustomer}.
 *
 * @see AddCustomerRequest
 *
 * @author    Avalara
 * @copyright � 2004 - 2011 Avalara, Inc.  All rights reserved.
 * @package   AvaCert
 */
class AddCustomerResult extends BaseResult {

}

?>
